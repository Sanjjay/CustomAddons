import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct , glob
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.ukturk'
Oo0Ooo = Addon ( OO0o , sys . argv )
O0O0OO0O0O0 = xbmcaddon . Addon ( id = OO0o )
iiiii = xbmc . translatePath ( 'special://home/addons/' ) + '/*.*'
ooo0OO = xbmc . translatePath ( 'special://home/addons/' )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + '/resources/art' , 'next.png' ) )
I11i11Ii = O0O0OO0O0O0 . getSetting ( 'adult' )
oO00oOo = O0O0OO0O0O0 . getSetting ( 'password' )
OOOo0 = int ( O0O0OO0O0O0 . getSetting ( 'count' ) )
Oooo000o = O0O0OO0O0O0 . getSetting ( 'enable_meta' )
IiIi11iIIi1Ii = xbmc . translatePath ( 'special://home/userdata/addon_data/' + OO0o )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'UKTurk.db' ) )
IiI = 'http://ukturk.offshorepastebin.com/ukturk2.jpg'
ooOo = 'https://www.googleapis.com/youtube/v3/search?q='
Oo = '&regionCode=US&part=snippet&hl=en_US&key=AIzaSyAd-YEOqZz9nXVzGtn3KWzYLbLaajhqIDA&type=video&maxResults=50'
o0O = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId='
IiiIII111iI = '&maxResults=50&key=AIzaSyAd-YEOqZz9nXVzGtn3KWzYLbLaajhqIDA'
IiII = open ( Oo0O , 'a' )
IiII . close ( )
if 28 - 28: Ii11111i * iiI1i1
def i1I1ii1II1iII ( ) :
 O0O0OO0O0O0 . setSetting ( 'fav' , 'no' )
 if not os . path . exists ( IiIi11iIIi1Ii ) :
  os . mkdir ( IiIi11iIIi1Ii )
 oooO0oo0oOOOO = O0oO ( IiI )
 o0oO0 = re . compile ( '<index>(.+?)</index>' ) . findall ( oooO0oo0oOOOO ) [ 0 ]
 oooO0oo0oOOOO = O0oO ( o0oO0 )
 oo00 = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)"' , re . DOTALL ) . findall ( oooO0oo0oOOOO )
 for o00 , Oo0oO0ooo , o0oOoO00o in oo00 :
  if not 'XXX' in o00 :
   i1 ( o00 , Oo0oO0ooo , 1 , o0oOoO00o , II1 )
  if 'XXX' in o00 :
   if I11i11Ii == 'true' :
    if oO00oOo == '' :
     oOOoo00O0O = xbmcgui . Dialog ( )
     i1111 = oOOoo00O0O . yesno ( 'Adult Content' , 'You have opted to show adult content' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'Lets Go' )
     if i1111 == 1 :
      i11 = xbmc . Keyboard ( '' , 'Set Password' )
      i11 . doModal ( )
      if ( i11 . isConfirmed ( ) ) :
       I11 = i11 . getText ( )
       O0O0OO0O0O0 . setSetting ( 'password' , I11 )
      i1 ( o00 , Oo0oO0ooo , 1 , o0oOoO00o , II1 )
   if I11i11Ii == 'true' :
    if oO00oOo <> '' :
     i1 ( o00 , Oo0oO0ooo , 1 , o0oOoO00o , II1 )
 i1 ( 'Favourites' , Oo0O , 15 , 'http://ukturk.offshorepastebin.com/UKTurk/thumbs/new/Uk%20turk%20thumbnails%20favourites.jpg' , II1 )
 i1 ( 'Search' , 'url' , 5 , 'http://ukturk.offshorepastebin.com/UKTurk/thumbs/new/Uk%20turk%20thumbnails%20search.jpg' , II1 )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 98 - 98: I1111 * o0o0Oo0oooo0 / I1I1i1 * oO0 / IIIi1i1I
def OOoOoo00oo ( url ) :
 O0O0OO0O0O0 . setSetting ( 'fav' , 'yes' )
 iiI11 = None
 file = open ( Oo0O , 'r' )
 iiI11 = file . read ( )
 oo00 = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( iiI11 )
 for OOooO in oo00 :
  OOoO00o = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>' , re . DOTALL ) . findall ( OOooO )
  for o00 , url , o0oOoO00o in OOoO00o :
   if '.txt' in url :
    i1 ( o00 , url , 1 , o0oOoO00o , II1 )
   else :
    II111iiii ( o00 , url , 2 , o0oOoO00o , II1 )
    if 48 - 48: I1Ii . IiIi1Iii1I1 - O0O0O0O00OooO % Ooooo % i1iIIIiI1I - OOoO000O0OO
def iiI1IiI ( name , url , iconimage ) :
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 II = '<FAV><item>\n<title>' + name + '</title>\n<link>' + url + '</link>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n</item></FAV>\n'
 IiII = open ( Oo0O , 'a' )
 IiII . write ( II )
 IiII . close ( )
 if 57 - 57: ooOoo0O
def OooO0 ( name , url , iconimage ) :
 iiI11 = None
 file = open ( Oo0O , 'r' )
 iiI11 = file . read ( )
 II11iiii1Ii = ''
 oo00 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iiI11 )
 for OOoO00o in oo00 :
  II = '\n<FAV><item>\n' + OOoO00o + '</item>\n'
  if name in OOoO00o :
   II = II . replace ( 'item' , ' ' )
  II11iiii1Ii = II11iiii1Ii + II
 file = open ( Oo0O , 'w' )
 file . truncate ( )
 file . write ( II11iiii1Ii )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 70 - 70: O00 / i1I1i1Ii11 . IIIIII11i1I - o0o0OOO0o0 % ooOOOo0oo0O0
def o0 ( name , url , iconimage , fanart ) :
 I11II1i = IIIII ( name )
 O0O0OO0O0O0 . setSetting ( 'tv' , I11II1i )
 oooO0oo0oOOOO = O0oO ( url )
 ooooooO0oo ( oooO0oo0oOOOO )
 if 'Index' in url :
  IIiiiiiiIi1I1 ( url )
 if 'XXX' in name : I1IIIii ( oooO0oo0oOOOO )
 oo00 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( oooO0oo0oOOOO )
 OOOo0 = str ( len ( oo00 ) )
 O0O0OO0O0O0 . setSetting ( 'count' , OOOo0 )
 O0O0OO0O0O0 . setSetting ( 'fav' , 'no' )
 for OOooO in oo00 :
  try :
   if '<sportsdevil>' in OOooO : oOoOooOo0o0 ( OOooO , url )
   elif '<iptv>' in OOooO : OOOO ( OOooO )
   elif '<Image>' in OOooO : OOO00 ( OOooO )
   elif '<text>' in OOooO : iiiiiIIii ( OOooO )
   elif '<scraper>' in OOooO : SCRAPER ( OOooO )
   elif '<redirect>' in OOooO : REDIRECT ( OOooO )
   elif '<oktitle>' in OOooO : O000OO0 ( OOooO )
   else : I11iii1Ii ( OOooO , url , iconimage )
  except : pass
  if 13 - 13: o0o0OOO0o0 % IiIi1Iii1I1 - i11iIiiIii . oO0 + I1I1i1
def O000OO0 ( item ) :
 o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 II111ii1II1i = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 OoOo00o = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 o0OOoo0OO0OOO = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 iI1iI1I1i1I = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 iIi11Ii1 = '##' + II111ii1II1i + '#' + OoOo00o + '#' + o0OOoo0OO0OOO + '#' + iI1iI1I1i1I + '##'
 o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 Ii11iII1 ( o00 , iIi11Ii1 , 17 , o0oOoO00o , II1 )
 if 51 - 51: I1I1i1 * I1Ii % O0O0O0O00OooO * I1I1i1 % Ooooo / ooOOOo0oo0O0
def iIIIIii1 ( name , url ) :
 oo000OO00Oo = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 oOOoo00O0O = xbmcgui . Dialog ( )
 oOOoo00O0O . ok ( oo000OO00Oo [ 0 ] , oo000OO00Oo [ 1 ] , oo000OO00Oo [ 2 ] , oo000OO00Oo [ 3 ] )
 if 51 - 51: IIIIII11i1I * O0O0O0O00OooO + ooOoo0O + I1Ii
def iiiiiIIii ( item ) :
 o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iIi11Ii1 = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 Ii11iII1 ( o00 , iIi11Ii1 , 9 , o0oOoO00o , II1 )
 if 66 - 66: IiIi1Iii1I1
def oO000Oo000 ( name , url ) :
 i111IiI1I = O0oO ( url )
 O0 ( name , i111IiI1I )
 if 30 - 30: O0O0O0O00OooO . O00 - I1111
def OOO00 ( item ) :
 Ii1iIiii1 = re . compile ( '<Image>(.+?)</Image>' ) . findall ( item )
 if len ( Ii1iIiii1 ) == 1 :
  o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  OOO = re . compile ( '<Image>(.+?)</Image>' ) . findall ( item ) [ 0 ]
  o0oOoO00o = OOO . replace ( 'http://imgur.com/' , 'http://i.imgur.com/' ) + '.jpg'
  OOO = OOO . replace ( 'http://imgur.com/' , 'http://i.imgur.com/' ) + '.jpg'
  Ii11iII1 ( o00 , OOO , 7 , o0oOoO00o , II1 )
 elif len ( Ii1iIiii1 ) > 1 :
  o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  Oo0oOOo = ''
  for OOO in Ii1iIiii1 :
   o0oOoO00o = OOO . replace ( 'http://imgur.com/' , 'http://i.imgur.com/' ) + '.jpg'
   OOO = OOO . replace ( 'http://imgur.com/' , 'http://i.imgur.com/' ) + '.jpg'
   Oo0oOOo = Oo0oOOo + '<Image>' + OOO + '</Image>'
  Oo0OoO00oOO0o = IiIi11iIIi1Ii
  o00 = IIIII ( o00 )
  OOO00O = os . path . join ( os . path . join ( Oo0OoO00oOO0o , '' ) , o00 + '.txt' )
  if not os . path . exists ( OOO00O ) : file ( OOO00O , 'w' ) . close ( )
  OOoOO0oo0ooO = open ( OOO00O , "w" )
  OOoOO0oo0ooO . write ( Oo0oOOo )
  OOoOO0oo0ooO . close ( )
  Ii11iII1 ( o00 , 'image' , 8 , o0oOoO00o , II1 )
  if 98 - 98: i1I1i1Ii11 * i1I1i1Ii11 / i1I1i1Ii11 + ooOoo0O
def OOOO ( item ) :
 o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 Oo0oO0ooo = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 i1 ( o00 , Oo0oO0ooo , 6 , o0oOoO00o , II1 )
 if 34 - 34: ooOOOo0oo0O0
def I1111I1iII11 ( url , iconimage ) :
 oooO0oo0oOOOO = O0oO ( url )
 Oooo0O0oo00oO = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( oooO0oo0oOOOO )
 IIi1i = [ ]
 for I1I1iIiII1 , o00 , url in Oooo0O0oo00oO :
  i11i1I1 = { "params" : I1I1iIiII1 , "name" : o00 , "url" : url }
  IIi1i . append ( i11i1I1 )
 list = [ ]
 for ii1I in IIi1i :
  i11i1I1 = { "name" : ii1I [ "name" ] , "url" : ii1I [ "url" ] }
  Oooo0O0oo00oO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ii1I [ "params" ] )
  for Oo0ooOo0o , Ii1i1 in Oooo0O0oo00oO :
   i11i1I1 [ Oo0ooOo0o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Ii1i1 . strip ( )
  list . append ( i11i1I1 )
 for ii1I in list :
  if '.ts' in ii1I [ "url" ] : Ii11iII1 ( ii1I [ "name" ] , ii1I [ "url" ] , 2 , iconimage , II1 )
  else : II111iiii ( ii1I [ "name" ] , ii1I [ "url" ] , 2 , iconimage , II1 )
  if 15 - 15: I1I1i1
def I11iii1Ii ( item , url , iconimage ) :
 Ii = iconimage
 ooo0O = url
 oOoO0o00OO0 = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 OOoO00o = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>' , re . DOTALL ) . findall ( item )
 for o00 , i1I1ii , iconimage in OOoO00o :
  if 'youtube.com/playlist?' in i1I1ii :
   oOOo0 = i1I1ii . split ( 'list=' ) [ 1 ]
   i1 ( o00 , i1I1ii , oo00O00oO , iconimage , II1 , description = oOOo0 )
 if len ( oOoO0o00OO0 ) == 1 :
  o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<link>(.+?)</link>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  if iconimage == 'ImageHere' : iconimage = Ii
  if '.ts' in url : Ii11iII1 ( o00 , url , 16 , iconimage , II1 , description = '' )
  elif 'movies' in ooo0O :
   iIiIIIi ( o00 , url , 2 , iconimage , int ( OOOo0 ) , isFolder = False )
  else : II111iiii ( o00 , url , 2 , iconimage , II1 )
 elif len ( oOoO0o00OO0 ) > 1 :
  o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  if iconimage == 'ImageHere' : iconimage = Ii
  print iconimage
  if '.ts' in url : Ii11iII1 ( o00 , url , 16 , iconimage , II1 , description = '' )
  elif 'movies' in ooo0O :
   iIiIIIi ( o00 , url , 3 , iconimage , int ( OOOo0 ) , isFolder = False )
  else : II111iiii ( o00 , url , 3 , iconimage , II1 )
  if 93 - 93: i1I1i1Ii11
def IIiiiiiiIi1I1 ( url ) :
 oooO0oo0oOOOO = O0oO ( url )
 oo00 = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)"' , re . DOTALL ) . findall ( oooO0oo0oOOOO )
 for o00 , url , I1IiiI in oo00 :
  if 'youtube.com/playlist?list=' in url :
   i1 ( o00 , url , 18 , I1IiiI , II1 )
  elif 'youtube.com/results?search_query=' in url :
   i1 ( o00 , url , 18 , I1IiiI , II1 )
  else :
   i1 ( o00 , url , 1 , I1IiiI , II1 )
   if 10 - 10: ooOoo0O
def OOooOO000 ( name , url , iconimage ) :
 if 'youtube.com/results?search_query=' in url :
  oOOo0 = url . split ( 'search_query=' ) [ 1 ]
  OOoOoo = ooOo + oOOo0 + Oo
  oO0000OOo00 = urllib2 . Request ( OOoOoo )
  oO0000OOo00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
  iiIi1IIiIi = urllib2 . urlopen ( oO0000OOo00 )
  oooO0oo0oOOOO = iiIi1IIiIi . read ( )
  iiIi1IIiIi . close ( )
  oooO0oo0oOOOO = oooO0oo0oOOOO . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '  ' , '' )
  oo00 = re . compile ( '"videoId": "(.+?)".+?"title": "(.+?)"' , re . DOTALL ) . findall ( oooO0oo0oOOOO )
  for oOO00Oo , name in oo00 :
   url = 'https://www.youtube.com/watch?v=' + oOO00Oo
   iconimage = 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % oOO00Oo
   II111iiii ( name , url , 2 , iconimage , II1 )
 elif 'youtube.com/playlist?list=' in url :
  oOOo0 = url . split ( 'playlist?list=' ) [ 1 ]
  OOoOoo = o0O + oOOo0 + IiiIII111iI
  oO0000OOo00 = urllib2 . Request ( OOoOoo )
  oO0000OOo00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
  iiIi1IIiIi = urllib2 . urlopen ( oO0000OOo00 )
  oooO0oo0oOOOO = iiIi1IIiIi . read ( )
  iiIi1IIiIi . close ( )
  oooO0oo0oOOOO = oooO0oo0oOOOO . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '  ' , '' )
  oo00 = re . compile ( '"title": "(.+?)".+?"videoId": "(.+?)"' , re . DOTALL ) . findall ( oooO0oo0oOOOO )
  for name , oOO00Oo in oo00 :
   url = 'https://www.youtube.com/watch?v=' + oOO00Oo
   iconimage = 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % oOO00Oo
   II111iiii ( name , url , 2 , iconimage , II1 )
   if 6 - 6: i1iIIIiI1I
def oOOo0oOo0 ( item ) :
 item = item . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' ) . replace ( '\'' , '' ) . replace ( '\n' , '' )
 OOoO00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)"' , re . DOTALL ) . findall ( item )
 for o00 , Oo0oO0ooo , o0oOoO00o in OOoO00o :
  if 'youtube.com/channel/' in Oo0oO0ooo :
   oOOo0 = Oo0oO0ooo . split ( 'channel/' ) [ 1 ]
   i1 ( o00 , Oo0oO0ooo , oo00O00oO , o0oOoO00o , II1 , description = oOOo0 )
  elif 'youtube.com/user/' in Oo0oO0ooo :
   oOOo0 = Oo0oO0ooo . split ( 'user/' ) [ 1 ]
   i1 ( o00 , Oo0oO0ooo , oo00O00oO , o0oOoO00o , II1 , description = oOOo0 )
  elif 'youtube.com/playlist?' in Oo0oO0ooo :
   oOOo0 = Oo0oO0ooo . split ( 'list=' ) [ 1 ]
   i1 ( o00 , Oo0oO0ooo , oo00O00oO , o0oOoO00o , II1 , description = oOOo0 )
  elif 'plugin://' in Oo0oO0ooo :
   IIooooo = HTMLParser ( )
   Oo0oO0ooo = IIooooo . unescape ( Oo0oO0ooo )
   i1 ( o00 , Oo0oO0ooo , oo00O00oO , o0oOoO00o , II1 )
  else :
   i1 ( o00 , Oo0oO0ooo , 1 , o0oOoO00o , II1 )
   if 1 - 1: IIIi1i1I / O0O0O0O00OooO % i1I1i1Ii11 * IIIIII11i1I . i11iIiiIii
def oOoOooOo0o0 ( item , url ) :
 oOoO0o00OO0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 III1Iiii1I11 = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( oOoO0o00OO0 ) + len ( III1Iiii1I11 ) == 1 :
  o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  oooO0oo0oOOOO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  Ii11iII1 ( o00 , url , 16 , o0oOoO00o , II1 )
 elif len ( oOoO0o00OO0 ) + len ( III1Iiii1I11 ) > 1 :
  o00 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  o0oOoO00o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  Ii11iII1 ( o00 , url , 3 , o0oOoO00o , II1 )
  if 9 - 9: Ooooo / IIIi1i1I - oO0 / I1111 / iiI1i1 - O0O0O0O00OooO
def I1IIIii ( link ) :
 if oO00oOo == '' :
  oOOoo00O0O = xbmcgui . Dialog ( )
  i1111 = oOOoo00O0O . yesno ( 'Adult Content' , 'You have opted to show adult content' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if i1111 == 1 :
   i11 = xbmc . Keyboard ( '' , 'Set Password' )
   i11 . doModal ( )
   if ( i11 . isConfirmed ( ) ) :
    I11 = i11 . getText ( )
    O0O0OO0O0O0 . setSetting ( 'password' , I11 )
  else : quit ( )
 elif oO00oOo <> '' :
  oOOoo00O0O = xbmcgui . Dialog ( )
  i1111 = oOOoo00O0O . yesno ( 'Adult Content' , 'Please enter the password you set' , 'to continue' , '' , 'Cancel' , 'OK' )
  if i1111 == 1 :
   i11 = xbmc . Keyboard ( '' , 'Enter Password' )
   i11 . doModal ( )
   if ( i11 . isConfirmed ( ) ) :
    I11 = i11 . getText ( )
   if I11 <> oO00oOo :
    quit ( )
  else : quit ( )
  if 91 - 91: i1I1i1Ii11 % o0o0Oo0oooo0 % iiI1i1
def IIi1I11I1II ( ) :
 i11 = xbmc . Keyboard ( '' , 'Search' )
 i11 . doModal ( )
 if ( i11 . isConfirmed ( ) ) :
  oOOo0 = i11 . getText ( )
  oOOo0 = oOOo0 . upper ( )
 else : quit ( )
 oooO0oo0oOOOO = O0oO ( IiI )
 OooOoooOo = re . compile ( '<link>(.+?)</link>' ) . findall ( oooO0oo0oOOOO )
 for Oo0oO0ooo in OooOoooOo :
  try :
   oooO0oo0oOOOO = O0oO ( Oo0oO0ooo )
   ii11IIII11I = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( oooO0oo0oOOOO )
   for OOooO in ii11IIII11I :
    oo00 = re . compile ( '<title>(.+?)</title>' ) . findall ( OOooO )
    for OOooo in oo00 :
     OOooo = OOooo . upper ( )
     if oOOo0 in OOooo :
      try :
       if 'Index' in Oo0oO0ooo : IIiiiiiiIi1I1 ( Oo0oO0ooo )
       elif '<sportsdevil>' in OOooO : oOoOooOo0o0 ( OOooO , Oo0oO0ooo )
       elif '<iptv>' in OOooO : OOOO ( OOooO )
       elif '<Image>' in OOooO : OOO00 ( OOooO )
       elif '<text>' in OOooO : iiiiiIIii ( OOooO )
       elif '<scraper>' in OOooO : SCRAPER ( OOooO )
       elif '<redirect>' in OOooO : REDIRECT ( OOooO )
       elif '<oktitle>' in OOooO : O000OO0 ( OOooO )
       else : I11iii1Ii ( OOooO , Oo0oO0ooo , o0oOoO00o )
      except : pass
  except : pass
  if 90 - 90: O0O0O0O00OooO % o0o0Oo0oooo0 / I1Ii
def IIi ( name , url , iconimage ) :
 Ii = iconimage
 i1Iii1i1I = [ ]
 OOoO00 = [ ]
 IiI111111IIII = [ ]
 oooO0oo0oOOOO = O0oO ( url )
 i1Ii = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( oooO0oo0oOOOO ) [ 0 ]
 oOoO0o00OO0 = [ ]
 if '<link>' in i1Ii :
  ii111iI1iIi1 = re . compile ( '<link>(.+?)</link>' ) . findall ( i1Ii )
  for OOOoo0OOo0 in ii111iI1iIi1 :
   oOoO0o00OO0 . append ( OOOoo0OOo0 )
 if '<sportsdevil>' in i1Ii :
  I11IiI = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( i1Ii )
  for O0ooO0Oo00o in I11IiI :
   O0ooO0Oo00o = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + O0ooO0Oo00o
   oOoO0o00OO0 . append ( O0ooO0Oo00o )
 ooO0oOOooOo0 = 1
 for i1I1ii11i1Iii in oOoO0o00OO0 :
  I1IiiiiI = i1I1ii11i1Iii
  if '(' in i1I1ii11i1Iii :
   i1I1ii11i1Iii = i1I1ii11i1Iii . split ( '(' ) [ 0 ]
   o0OIiII = str ( I1IiiiiI . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   i1Iii1i1I . append ( i1I1ii11i1Iii )
   OOoO00 . append ( o0OIiII )
  else :
   ii1iII1II = i1I1ii11i1Iii . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
   i1Iii1i1I . append ( i1I1ii11i1Iii )
   OOoO00 . append ( 'Link ' + str ( ooO0oOOooOo0 ) )
  ooO0oOOooOo0 = ooO0oOOooOo0 + 1
 oOOoo00O0O = xbmcgui . Dialog ( )
 Iii1I1I11iiI1 = oOOoo00O0O . select ( 'Choose a link..' , OOoO00 )
 if Iii1I1I11iiI1 < 0 : quit ( )
 else :
  url = i1Iii1i1I [ Iii1I1I11iiI1 ]
  I1I1i1I ( name , url , iconimage )
  if 30 - 30: I1111
def I1Ii1iI1 ( url ) :
 II = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( II )
 if 87 - 87: IIIi1i1I . IIIIII11i1I
def I1I1i1I ( name , url , iconimage ) :
 try :
  if 'sop://' in url :
   url = urllib . quote ( url )
   url = 'plugin://program.plexus/?mode=2&url=%s&name=%s' % ( url , name . replace ( ' ' , '+' ) )
   O0OO0O ( name , url , iconimage )
  elif 'acestream://' in url or '.acelive' in url :
   url = urllib . quote ( url )
   url = 'plugin://program.plexus/?mode=1&url=%s&name=%s' % ( url , name . replace ( ' ' , '+' ) )
   O0OO0O ( name , url , iconimage )
  elif 'plugin://plugin.video.SportsDevil/' in url :
   O0OO0O ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   O0OO0O ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   OO ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   OO ( name , url , iconimage )
  else : OO ( name , url , iconimage )
 except :
  OoOoO ( 'UKTurk' , 'Stream Unavailable' , '3000' , I1IiiI )
  if 43 - 43: i11iIiiIii + IIIi1i1I * I1I1i1 * o0o0OOO0o0 * Ii11111i
def o00oO0oo0OO ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 57 - 57: o0o0OOO0o0 % O00 + O0O0O0O00OooO - IIIi1i1I
def OO ( name , url , iconimage ) :
 o0OIiI1i = True
 o0Oo00 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; o0Oo00 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = o0Oo00 )
 o0Oo00 . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0Oo00 )
 if 32 - 32: O0O0O0O00OooO . IIIIII11i1I * ooOoo0O
def O0OO0O ( name , url , iconimage ) :
 o0OIiI1i = True
 o0Oo00 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; o0Oo00 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = o0Oo00 )
 oOOoo00O0O = xbmcgui . Dialog ( )
 xbmc . Player ( ) . play ( url , o0Oo00 , False )
 if 93 - 93: O0O0O0O00OooO % o0o0Oo0oooo0 . O00 . i11iIiiIii
def oOOoo00O00o ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 98 - 98: OOoO000O0OO + IIIIII11i1I + i1iIIIiI1I % I1111
def oooooo0O000o ( url ) :
 OoO = O0O0OO0O0O0 . getSetting ( 'layout' )
 if OoO == 'Listers' : O0O0OO0O0O0 . setSetting ( 'layout' , 'Category' )
 else : O0O0OO0O0O0 . setSetting ( 'layout' , 'Listers' )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 51 - 51: I1111 * OOoO000O0OO
def O0oO ( url ) :
 oO0000OOo00 = urllib2 . Request ( url )
 oO0000OOo00 . add_header ( 'User-Agent' , 'mat' )
 iiIi1IIiIi = urllib2 . urlopen ( oO0000OOo00 )
 oooO0oo0oOOOO = iiIi1IIiIi . read ( )
 iiIi1IIiIi . close ( )
 oooO0oo0oOOOO = oooO0oo0oOOOO . replace ( '</fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in oooO0oo0oOOOO : oooO0oo0oOOOO = OO0ooOOO0OOO ( oooO0oo0oOOOO )
 return oooO0oo0oOOOO
 if 63 - 63: IiIi1Iii1I1 * i1I1i1Ii11
def oo ( ) :
 iIi1 = [ ]
 OoOOoOooooOOo = sys . argv [ 2 ]
 if len ( OoOOoOooooOOo ) >= 2 :
  I1I1iIiII1 = sys . argv [ 2 ]
  oOo0O = I1I1iIiII1 . replace ( '?' , '' )
  if ( I1I1iIiII1 [ len ( I1I1iIiII1 ) - 1 ] == '/' ) :
   I1I1iIiII1 = I1I1iIiII1 [ 0 : len ( I1I1iIiII1 ) - 2 ]
  oo0O0 = oOo0O . split ( '&' )
  iIi1 = { }
  for ooO0oOOooOo0 in range ( len ( oo0O0 ) ) :
   iI = { }
   iI = oo0O0 [ ooO0oOOooOo0 ] . split ( '=' )
   if ( len ( iI ) ) == 2 :
    iIi1 [ iI [ 0 ] ] = iI [ 1 ]
 return iIi1
 if 89 - 89: O0O0O0O00OooO + I1Ii * ooOoo0O * O00
def OoOoO ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 37 - 37: I1111 - Ii11111i - O0O0O0O00OooO
def IIIII ( string ) :
 o0o0O0O00oOOo = re . compile ( '\[(.+?)\]' ) . findall ( string )
 for iIIIiIi in o0o0O0O00oOOo : string = string . replace ( iIIIiIi , '' ) . replace ( '[/]' , '' ) . replace ( '[]' , '' )
 return string
 if 100 - 100: oO0 / O0O0O0O00OooO % I1I1i1 % IIIi1i1I % OOoO000O0OO
def O00oO000O0O ( string ) :
 string = string . split ( ' ' )
 I1i1i1iii = ''
 for I1111i in string :
  iIIii = '[B][COLOR red]' + I1111i [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + I1111i [ 1 : ] + '[/COLOR][/B] '
  I1i1i1iii = I1i1i1iii + iIIii
 return I1i1i1iii
 if 92 - 92: O00 + i1iIIIiI1I % OOoO000O0OO
def iIiIIIi ( name , url , mode , iconimage , itemcount , isFolder = False ) :
 if Oooo000o == 'true' :
  if not 'COLOR' in name :
   oOo0 = name . partition ( '(' )
   i1iI = ""
   Oo0O0 = ""
   if len ( oOo0 ) > 0 :
    i1iI = oOo0 [ 0 ]
    Oo0O0 = oOo0 [ 2 ] . partition ( ')' )
   if len ( Oo0O0 ) > 0 :
    Oo0O0 = Oo0O0 [ 0 ]
   Ooo0OOoOoO0 = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
   oOo0OOoO0 = Ooo0OOoOoO0 . get_meta ( 'movie' , name = i1iI , year = Oo0O0 )
   IIo0Oo0oO0oOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&site=" + str ( oo00OO0000oO ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
   o0OIiI1i = True
   o0Oo00 = xbmcgui . ListItem ( name , iconImage = oOo0OOoO0 [ 'cover_url' ] , thumbnailImage = oOo0OOoO0 [ 'cover_url' ] )
   o0Oo00 . setInfo ( type = "Video" , infoLabels = oOo0OOoO0 )
   o0Oo00 . setProperty ( "IsPlayable" , "true" )
   I1II1 = [ ]
   if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'yes' : I1II1 . append ( ( '[COLOR red]Remove from UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
   if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'no' : I1II1 . append ( ( '[COLOR white]Add to UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=12&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
   o0Oo00 . addContextMenuItems ( I1II1 , replaceItems = False )
   if not oOo0OOoO0 [ 'backdrop_url' ] == '' : o0Oo00 . setProperty ( 'fanart_image' , oOo0OOoO0 [ 'backdrop_url' ] )
   else : o0Oo00 . setProperty ( 'fanart_image' , II1 )
   o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0Oo0oO0oOO00 , listitem = o0Oo00 , isFolder = isFolder , totalItems = itemcount )
   return o0OIiI1i
 else :
  IIo0Oo0oO0oOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&site=" + str ( oo00OO0000oO ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
  o0OIiI1i = True
  o0Oo00 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
  o0Oo00 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
  o0Oo00 . setProperty ( 'fanart_image' , II1 )
  o0Oo00 . setProperty ( "IsPlayable" , "true" )
  I1II1 = [ ]
  if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'yes' : I1II1 . append ( ( '[COLOR red]Remove from UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'no' : I1II1 . append ( ( '[COLOR white]Add to UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=12&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  o0Oo00 . addContextMenuItems ( I1II1 , replaceItems = False )
  o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0Oo0oO0oOO00 , listitem = o0Oo00 , isFolder = isFolder )
  return o0OIiI1i
  if 86 - 86: iiI1i1 / IiIi1Iii1I1 . I1I1i1
def i1 ( name , url , mode , iconimage , fanart , description = '' ) :
 IIo0Oo0oO0oOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o0OIiI1i = True
 o0Oo00 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o0Oo00 . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 o0Oo00 . setProperty ( 'fanart_image' , fanart )
 I1II1 = [ ]
 if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'yes' : I1II1 . append ( ( '[COLOR red]Remove from UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'no' : I1II1 . append ( ( '[COLOR white]Add to UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=12&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 o0Oo00 . addContextMenuItems ( I1II1 , replaceItems = False )
 if 'plugin://' in url :
  IIo0Oo0oO0oOO00 = url
 o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0Oo0oO0oOO00 , listitem = o0Oo00 , isFolder = True )
 return o0OIiI1i
 if 19 - 19: Ooooo % I1111 % IIIIII11i1I * O0O0O0O00OooO % Ii11111i
def Ii11iII1 ( name , url , mode , iconimage , fanart , description = '' ) :
 IIo0Oo0oO0oOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o0OIiI1i = True
 o0Oo00 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o0Oo00 . setProperty ( 'fanart_image' , fanart )
 I1II1 = [ ]
 if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'yes' : I1II1 . append ( ( '[COLOR red]Remove from UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'no' : I1II1 . append ( ( '[COLOR white]Add to UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=12&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 o0Oo00 . addContextMenuItems ( I1II1 , replaceItems = False )
 o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0Oo0oO0oOO00 , listitem = o0Oo00 , isFolder = False )
 return o0OIiI1i
 if 67 - 67: oO0 . o0o0Oo0oooo0
def II111iiii ( name , url , mode , iconimage , fanart , description = '' ) :
 IIo0Oo0oO0oOO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o0OIiI1i = True
 o0Oo00 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o0Oo00 . setProperty ( 'fanart_image' , fanart )
 o0Oo00 . setProperty ( "IsPlayable" , "true" )
 I1II1 = [ ]
 if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'yes' : I1II1 . append ( ( '[COLOR red]Remove from UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 if O0O0OO0O0O0 . getSetting ( 'fav' ) == 'no' : I1II1 . append ( ( '[COLOR white]Add to UK Turk Favourites[/COLOR]' , 'XBMC.RunPlugin(%s?mode=12&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 o0Oo00 . addContextMenuItems ( I1II1 , replaceItems = False )
 o0OIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0Oo0oO0oOO00 , listitem = o0Oo00 , isFolder = False )
 return o0OIiI1i
 if 27 - 27: ooOOOo0oo0O0 % oO0
def o0oooOO00 ( url , name ) :
 iiIiii1IIIII = O0oO ( url )
 if len ( iiIiii1IIIII ) > 1 :
  Oo0OoO00oOO0o = IiIi11iIIi1Ii
  OOO00O = os . path . join ( os . path . join ( Oo0OoO00oOO0o , '' ) , name + '.txt' )
  if not os . path . exists ( OOO00O ) :
   file ( OOO00O , 'w' ) . close ( )
  o00o = open ( OOO00O )
  IIIIiiIiiI = o00o . read ( )
  if IIIIiiIiiI == iiIiii1IIIII : pass
  else :
   O0 ( 'UKTurk' , iiIiii1IIIII )
   OOoOO0oo0ooO = open ( OOO00O , "w" )
   OOoOO0oo0ooO . write ( iiIiii1IIIII )
   OOoOO0oo0ooO . close ( )
   if 10 - 10: IiIi1Iii1I1 % IiIi1Iii1I1 - IiIi1Iii1I1 . i1I1i1Ii11
def O0 ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 o0OoOo00o0o = xbmcgui . Window ( id )
 I1II1I11I1I = 50
 while ( I1II1I11I1I > 0 ) :
  try :
   xbmc . sleep ( 10 )
   I1II1I11I1I -= 1
   o0OoOo00o0o . getControl ( 1 ) . setLabel ( heading )
   o0OoOo00o0o . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 54 - 54: I1111 + O0O0O0O00OooO - o0o0Oo0oooo0 % i11iIiiIii
def iII1iIi11i ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 OOO00O = os . path . join ( os . path . join ( IiIi11iIIi1Ii , '' ) , name + '.txt' )
 o00o = open ( OOO00O )
 IIIIiiIiiI = o00o . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( IIIIiiIiiI )
 O0O0OO0O0O0 . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 o0ooooO0o0O = '/resources/art'
 iiIi11iI1iii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'next_focus.png' ) )
 oo000 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'next1.png' ) )
 o0000oO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'previous_focus.png' ) )
 iI1i111I1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'previous.png' ) )
 i11i1ii1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'close_focus.png' ) )
 o0OO0o0o00o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'close.png' ) )
 oOo0OOOoOO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + o0ooooO0o0O , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 I11IIIi = pyxbmct . Image ( oOo0OOOoOO )
 window . placeControl ( I11IIIi , - 10 , - 10 , 130 , 70 )
 iIi11Ii1 = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = o0000oO , noFocusTexture = iI1i111I1Ii , textColor = iIi11Ii1 , focusedColor = iIi11Ii1 )
 Next = pyxbmct . Button ( '' , focusTexture = iiIi11iI1iii , noFocusTexture = oo000 , textColor = iIi11Ii1 , focusedColor = iIi11Ii1 )
 Quit = pyxbmct . Button ( '' , focusTexture = i11i1ii1I , noFocusTexture = o0OO0o0o00o , textColor = iIi11Ii1 , focusedColor = iIi11Ii1 )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 1 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , iIIiiI1II1i11 )
 window . connect ( Next , o0o0 )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 49 - 49: i1iIIIiI1I - i11iIiiIii . o0o0OOO0o0 * O00 % i1I1i1Ii11 + o0o0Oo0oooo0
def o0o0 ( ) :
 oOO0OOOo = int ( O0O0OO0O0O0 . getSetting ( 'pos' ) )
 oo0o0000 = int ( oOO0OOOo ) + 1
 O0O0OO0O0O0 . setSetting ( 'pos' , str ( oo0o0000 ) )
 iiI = len ( images )
 Icon . setImage ( images [ int ( oo0o0000 ) ] )
 Previous . setVisible ( True )
 if int ( oo0o0000 ) == int ( iiI ) - 1 :
  Next . setVisible ( False )
  if 82 - 82: IIIi1i1I + I1Ii
def iIIiiI1II1i11 ( ) :
 oOO0OOOo = int ( O0O0OO0O0O0 . getSetting ( 'pos' ) )
 O00O = int ( oOO0OOOo ) - 1
 O0O0OO0O0O0 . setSetting ( 'pos' , str ( O00O ) )
 Icon . setImage ( images [ int ( O00O ) ] )
 Next . setVisible ( True )
 if int ( O00O ) == 0 :
  Previous . setVisible ( False )
  if 86 - 86: IIIi1i1I . Ii11111i - I1111 . I1Ii + O00
def OO0ooOOO0OOO ( gobble ) :
 gobble = gobble . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
 gobble = gobble + '=='
 gobble = gobble . decode ( 'base64' )
 return gobble
 if 57 - 57: O0O0O0O00OooO . o0o0Oo0oooo0 . IIIIII11i1I * i11iIiiIii + o0o0OOO0o0 . IIIIII11i1I
def ooooooO0oo ( link ) :
 try :
  oo0O00Oooo0O0 = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if oo0O00Oooo0O0 == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 34 - 34: ooOOOo0oo0O0 . O0O0O0O00OooO % Ii11111i * i1I1i1Ii11 + oO0
I1I1iIiII1 = oo ( ) ; Oo0oO0ooo = None ; o00 = None ; oo00O00oO = None ; oo00OO0000oO = None ; o0oOoO00o = None
try : oo00OO0000oO = urllib . unquote_plus ( I1I1iIiII1 [ "site" ] )
except : pass
try : Oo0oO0ooo = urllib . unquote_plus ( I1I1iIiII1 [ "url" ] )
except : pass
try : o00 = urllib . unquote_plus ( I1I1iIiII1 [ "name" ] )
except : pass
try : oo00O00oO = int ( I1I1iIiII1 [ "mode" ] )
except : pass
try : o0oOoO00o = urllib . unquote_plus ( I1I1iIiII1 [ "iconimage" ] )
except : pass
try : II1 = urllib . unquote_plus ( I1I1iIiII1 [ "fanart" ] )
except : pass
if 77 - 77: O00 + I1I1i1 . IiIi1Iii1I1 * o0o0OOO0o0 + OOoO000O0OO + OOoO000O0OO
try : I1ii1I1iiii = urllib . unquote_plus ( [ "description" ] )
except : pass
if 36 - 36: I1111 . I1Ii
if oo00O00oO == None or Oo0oO0ooo == None or len ( Oo0oO0ooo ) < 1 : i1I1ii1II1iII ( )
elif oo00O00oO == 1 : o0 ( o00 , Oo0oO0ooo , o0oOoO00o , II1 )
elif oo00O00oO == 2 : I1I1i1I ( o00 , Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 3 : IIi ( o00 , Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 4 : OO ( o00 , Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 5 : IIi1I11I1II ( )
elif oo00O00oO == 6 : I1111I1iII11 ( Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 7 : I1Ii1iI1 ( Oo0oO0ooo )
elif oo00O00oO == 8 : iII1iIi11i ( o00 )
elif oo00O00oO == 9 : oO000Oo000 ( o00 , Oo0oO0ooo )
elif oo00O00oO == 10 : DOSCRAPER ( o00 , Oo0oO0ooo )
elif oo00O00oO == 11 : oOOoo00O00o ( Oo0oO0ooo )
elif oo00O00oO == 12 : iiI1IiI ( o00 , Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 13 : oooooo0O000o ( Oo0oO0ooo )
elif oo00O00oO == 14 : OooO0 ( o00 , Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 15 : OOoOoo00oo ( Oo0oO0ooo )
elif oo00O00oO == 16 : O0OO0O ( o00 , Oo0oO0ooo , o0oOoO00o )
elif oo00O00oO == 17 : iIIIIii1 ( o00 , Oo0oO0ooo )
elif oo00O00oO == 18 : OOooOO000 ( o00 , Oo0oO0ooo , o0oOoO00o )
if 56 - 56: IIIi1i1I . Ooooo . oO0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
