
import xbmcgui

xbmcgui.Dialog().ok('Addon Broken', 'Waiting for a fix from the developer', 'Will Update automatically when fixed', 'Press OK to Exit.')