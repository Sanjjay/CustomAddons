skin.amber.mod
==========

AmberMod skin for Kodi/XBMC
