import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,net
net = net.Net()

addon_id        = 'plugin.program.ukcheck'
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart          = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
mot             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'mot.jpg'))
tax             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'tax.jpg'))
headers         ={'User-Agent':'Dalvik/2.1.0 (Linux; U; Android 6.0.1; SM-G935F Build/MMB29K)'}	

def GETMANU():
        makes=['ABARTH','AC','ADLY','AEON','AJP','AJS','ALFA\x20ROMEO','ALFER','APRILIA','ARIEL',
       'ASIA','ASQUITH','ASTON\x20MARTIN','ATALA','AUDI','BAJAJ','BASHAN','BATTISTINIS',
       'BEDFORD','BENELLI','BENTLEY','BETAMOTOR','BIMOTA','BMW','BOOM','BRANSON','BRISTOL',
       'BRITISH\x20TRACKSTAR','BSA','BUELL','CADILLAC','CAGIVA','CATERHAM','CCM','CHAMP',
       'CHEVROLET','CH\x20RACING','CHRYSLER','CHRYSLER\x20JEEP','CITROEN','COLEMAN\x20MILNE',
       'CORVETTE','CPI','CZ','DACIA','DAELIM','DAEWOO','DAIHATSU','DAIMLER','DERBI','DI\x20BLASI',
       'DODGE','DUCATI','EASY\x20RIDER','EGO','ENFIELD','EUROPED','EVT','FACTORY','FERRARI','FIAT',
       'FORD','FOSTI','FSO\x20CARS','FUSO','GARELLI','GAS\x20GAS','GENERAL\x20MOTORS','GENERIC','GILERA',
       'HARLEY\x20DAVIDSON','HARTFORD','HERO','HERO\x20PUCH','HESKETH','HIGHLAND','HIMO',
       'HMC\x20SPORTSCARS','HONDA','HUMMER','HUSABERG','HUSQVARNA','HYOSUNG','HYUNDAI','INDIAN',
       'INFINITI','INNOCENTI','ISUZU','ITALJET','ITALVEL','IVECO','JAGUAR','JAWA','JEEP','JENSEN',
       'JIALING','JIANSHE','JINLUN','JONWAY','KANGDA','KANUNI','KAWASAKI','KAWATA','KEEN','KIA',
       'KINETIC','KINLON','KTM','KYMCO','LADA','LAMBORGHINI','LAMBRETTA','LANCIA','LAND\x20ROVER',
       'LANYING','LAVERDA','LDV','LEXUS','LIFAN\x20HONGDA','LML','LONCIN','LONDON\x20TAXIS\x20INT',
       'LOTUS','MAHINDRA','MALAGUTI','MANET\x20PUCH','MARCOS','MASERATI','MATCHLESS','MAZDA','MBK',
       'MCLAREN','MERCEDES','MG','MICROCAR','MIG','MINI','MINSK','MITSUBISHI','MITSUBISHI\x20FUSO',
       'MODENAS','MONDIAL','MONTESA','MOPEDS\x20SLOVAKIA','MORGAN','MORINI','MOSKVICH','MOTO\x20BENO',
       'MOTO\x20GUZZI','MOTOMANET','MOTOR\x20HISPANIA','MOTOR\x20JIKOV','MOTO\x20ROMA','MV\x20AGUSTA',
       'MZ','NEVAL','NICE','NISSAN','NOBLE','NORTON','OPEL','OXYGEN','PENTA','PERODUA','PEUGEOT','PGO',
       'PIAGGIO','POLSKI\x20FIAT','PORSCHE','PROTON','PUCH','PULSE','QINGQI','REGENT','RELIANT','RENAULT',
       'RIEJU','ROLLS\x20ROYCE','ROVER','ROVIGO','SAAB','SACHS','SANLI','SANTANA','SANYANG','SAO','SEAT',
       'SECMA','SERVETA','SHE\x20LUNG','SHERCO','SIAMOTO','SIMSON','SKODA','SMART\x20\x28MCC\x29','SSANGYONG',
       'STANDARD\x20MOTOR\x20\x28SMC\x29','STARWAY','SUBARU','SUNDIRO','SUZUKI','SYM','TAISHAN','TALBOT','TATA',
       'TESLA','TGB','TOMOS','TOYOTA','TRABANT','TRIUMPH','TVR','UMM','URALMOTO','URBAN','UVM','VAUXHALL','VELOSOLEX',
       'VICTORY','VOLKSWAGEN','VOLVO','VULCAN','WARTBURG','WESTFIELD','YAMAHA','YAMOTO','YUGO','ZEBRETTA','ZY\x20MOTOR']
        addLink('[COLOR gold]Select Manufacturer : [/COLOR]','url','mode','iconimage','fanart',description='')
        for make in makes:
                 addDir(make,'url',1,icon,fanart)
                
def GETREG(name):
        reg =''
        keyboard = xbmc.Keyboard(reg, 'Enter registration number of your ' + name)
        keyboard.doModal()
        if keyboard.isConfirmed():
                reg = keyboard.getText().replace(' ','').capitalize()
        if len(reg)>1:
                GETSPEC(name,reg)
        else: quit()

def GETSPEC(name,reg):
        postdata={'registration':reg.upper(),'manufacturer':name}
        result = net.http_POST('https://www.check-mot.service.gov.uk/',postdata, headers).content.replace('\n','').replace('  ','')
        result=result.encode('ascii', 'ignore')
        if 'No vehicle that' in result:
                dialog = xbmcgui.Dialog()
                dialog.ok('UK Vehicle Check',\
                          '- Vehicle details could not be validated -',\
                          'Check you entered correct manufacturer and registration')
                quit()     
        reg=re.compile('span class="registrationNumber">(.+?)</span>').findall(result)[0].upper()
        make=re.compile('<span>Vehicle make</span><span class="strong">(.+?)</span>').findall(result)[0].title()
        model=re.compile('<span>Vehicle model</span><span class="strong">(.+?)</span>').findall(result)[0].title()
        datefirstused=re.compile('<span>Date first used</span><span class="strong">(.+?)</span>').findall(result)[0].title()
        fuel=re.compile('<span>Fuel type</span><span class="strong">(.+?)</span>').findall(result)[0].title()
        colour=re.compile('<span>Colour</span><span class="strong">(.+?)</span>').findall(result)[0].title()
        addLink('[COLOR gold]Vehicle Registration : [/COLOR]'+reg,'url','mode',icon,fanart)
        addLink('[COLOR gold]Vehicle Make : [/COLOR]'+make,'url','mode',icon,fanart)
        addLink('[COLOR gold]Vehicle Model : [/COLOR]'+model,'url','mode',icon,fanart)
        addLink('[COLOR gold]Vehicle First Registered : [/COLOR]'+datefirstused,'url','mode',icon,fanart)
        addLink('[COLOR gold]Vehicle Colour : [/COLOR]'+colour,'url','mode',icon,fanart)
        addLink('[COLOR gold]Vehicle Fuel Type : [/COLOR]'+fuel,'url','mode',icon,fanart)
        addLink('','url','mode',icon,fanart)
        addDir('[COLOR gold]View Tax Details[/COLOR]','url',2,tax,fanart,description=name+'@'+reg)
        addDir('[COLOR gold]View MOT Details[/COLOR]','url',3,mot,fanart,description=name+'@'+reg)
       
def GETTAX(description):
        reg=description.split('%2540')[1]
        make=description.split('%2540')[0]
        taxresult = net.http_GET('http://bcapps.uk/apps/carquery/query.php?vrn='+reg.title()+'&make='+make.title(),headers).content
        taxresult=taxresult.encode('ascii', 'ignore')      
        taxexpire = re.compile('"ved":"(.+?)"').findall(taxresult)[0]
        if not '20' in taxexpire:taxexpire = 'untaxed'
        taxsorn = re.compile('"sorn":"(.+?)"').findall(taxresult)[0]
        if taxsorn <> 'No':taxsorn = 'Yes'
        addLink('[COLOR gold]Vehicle Tax Expiry Date : [/COLOR]'+taxexpire.title(),'url','mode',tax,fanart)
        addLink('[COLOR gold]Vehicle Sorn Status : [/COLOR]'+taxsorn.title(),'url','mode',tax,fanart)

def GETMOT(description):
        reg=description.split('%2540')[1]
        make=description.split('%2540')[0]
        postdata={'registration':reg.upper(),'manufacturer':make.upper()}
        result = net.http_POST('https://www.check-mot.service.gov.uk/',postdata, headers).content.replace('\n','').replace('  ','')
        result=result.encode('ascii', 'ignore')
        tests=re.compile('margin-bottom:20px;"><li>(.+?)></div></li></ul><ul class="ul-data testresult"').findall(result)
        for test in tests:
                testdate=re.compile('<span>Test date</span><span class="strong">(.+?)</span>').findall(test)[0]
                addLink('[COLOR gold]Test Date : [/COLOR]'+testdate,result,4,mot,fanart,description=testdate+'@'+reg+'@'+make)

def GETMOTDETAIL(url,description):
        reg=description.split('%2540')[2]
        make=description.split('%2540')[1]
        testdate=description.split('%2540')[0]
        tests=re.compile('margin-bottom:20px;"><li>(.+?)></div></li></ul><ul class="ul-data testresult"').findall(url)
        for test in tests:
                testdate=testdate.replace('%2520',' ').replace('%2B',' ')
                matcher = re.compile('<span>Test date</span><span class="strong">(.+?)</span>').findall(test)[0]
                if matcher == testdate:
                        miles=re.compile('<span>Odometer reading</span><span class="strong">(.+?)</span>').findall(test)[0]
                        testdate=re.compile('<span>Test date</span><span class="strong">(.+?)</span>').findall(test)[0]
                        try:testexpire=re.compile('<span>Expiry date</span><span class="strong">(.+?)</span>').findall(test)[0]
                        except:pass
                        testresult=re.compile('<span>Test Result</span><span class="strong">(.+?)</span>').findall(test)[0]
                        motnum=re.compile('<span>MOT test number</span><span class="strong">(.+?)</span>').findall(test)[0]
                        advisories=re.compile('<div class="group advice-comment">(.+?)</div>').findall(test)
                        if len(advisories)==0:
                                advisories = ['None']
                        failures=re.compile('<div class="group failure-comment">(.+?)</div>').findall(test)
                        string = '[COLOR gold]Date : [/COLOR]'+testdate+\
                                 '\n[COLOR gold]Mileage : [/COLOR]'+miles+\
                                 '\n[COLOR gold]Result : [/COLOR]'+testresult+\
                                 '\n[COLOR gold]MOT test number : [/COLOR]'+motnum+\
                                 '\n\n[COLOR gold]Advisories:[/COLOR]\n'
                        for advisory in advisories:
                                string=string+advisory.capitalize()+'\n'
                        if testresult=='Fail':
                                string=string+'\n\n[COLOR gold]Failures:[/COLOR]\n'
                                for fail in failures:
                                        string=string+fail.capitalize()+'\n'
                        showText('Test Results - '+testdate, string)
              
def showText(heading, text):
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(100)
        win = xbmcgui.Window(id)
        retry = 50
        while (retry > 0):
                try:
                    xbmc.sleep(10)
                    retry -= 1
                    win.getControl(1).setLabel(heading)
                    win.getControl(5).setText(text)
                    return
                except:
                    pass       

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param

def addLink(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
 
def addDir(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
 
params=get_params(); url=None; name=None; mode=None; site=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: mode=int(params["mode"])
except: pass
try: description=urllib.quote_plus(params["description"])
except: pass

  
if mode==None or url==None or len(url)<1: GETMANU()
elif mode==1: GETREG(name)
elif mode==2: GETTAX(description)
elif mode==3: GETMOT(description)
elif mode==4: GETMOTDETAIL(url,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
