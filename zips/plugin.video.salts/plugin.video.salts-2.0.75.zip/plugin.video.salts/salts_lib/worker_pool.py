"""
    SALTS XBMC Addon
    Copyright (C) 2016 tknorris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import Queue
import threading
import log_utils

Empty = Queue.Empty

class WorkerPool(object):
    def __init__(self, max_workers=None):
        self.max_workers = max_workers
        self.workers = []
        self.q = Queue.Queue()
    
    def request(self, func, args=None, kwargs=None):
        if args is None: args = []
        if kwargs is None: kwargs = {}
        worker = threading.Thread(target=func, args=([self.q] + args))
        worker.daemon = True
        worker.start()
        self.workers.append(worker)
        log_utils.log('Worker: %s (%s) started for |%s| with args: |%s| kwargs: |%s|' % (worker.name, worker, func.__name__, args, kwargs))
    
    def receive(self, timeout):
        return self.q.get(True, timeout)
    
    def close(self):
        return reap_workers(self.workers)

def reap_workers(workers, timeout=0):
    """
    Reap thread/process workers; don't block by default; return un-reaped workers
    """
    log_utils.log('In Reap: %s' % (workers), log_utils.LOGDEBUG)
    living_workers = []
    for worker in workers:
        if worker:
            log_utils.log('Reaping: %s' % (worker.name), log_utils.LOGDEBUG)
            worker.join(timeout)
            if worker.is_alive():
                log_utils.log('Worker %s still running' % (worker.name), log_utils.LOGDEBUG)
                living_workers.append(worker)
    return living_workers

