'''
hyfytv deccandelight plugin
Copyright (C) 2018 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from main import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests, base64, random
import resources.lib.cfscrape as cfscrape
import HTMLParser
import xbmc

class hyfy(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://hyfytv.in/language/'
        self.icon = self.ipath + 'hyfy.png'
        self.qvalues = ['Low','Med','Default','Good','High']
        self.bvalues = ['250','400','600','800','1200']
        self.qual = self.qvalues[int(self.settings('thopqual'))]
        self.bitrate = self.bvalues[int(self.settings('thopqual'))]
        lurl = self.bu[:-9] + 'wp-includes/js/comment-reply.min.js'
        self.ckstr = cfscrape.get_cookie_string(lurl,headers=self.hdr)[0]
        self.cj={}
        cookies = self.ckstr.split(";")
        for c in cookies:
             k,v = c.split("=")
             self.cj[k] = v
        self.list = {'01Tamil TV': self.bu + 'tamil/',
                     '02Telugu TV': self.bu + 'telugu/',
                     '03Malayalam TV': self.bu + 'malayalam/',
                     '04Kannada TV': self.bu + 'kannada/',
                     '05Hindi TV': self.bu + 'hindi/',
                     '06English TV': self.bu + 'english/',
                     '07Urdu TV': self.bu + 'urdu/',
                     '08Marathi TV': self.bu + 'marathi/',
                     '09Punjabi TV': self.bu + 'punjabi/',
                     '10Gujarathi TV': self.bu + 'gujarathi/',
                     '11Bangla TV': self.bu + 'bengali/',
                     '12Odiya TV': self.bu + 'odiya/'}
            
    def get_menu(self):
        return (self.list,7,self.icon)
        
    def get_items(self,iurl):
        channels = []
        h = HTMLParser.HTMLParser()
        mlink = SoupStrainer('div', {'class':'content'})
        plink = SoupStrainer('div', {'class':'resppages'})
        nextpg = True
        while nextpg:
            html = requests.get(iurl, headers=self.hdr, cookies=self.cj).text
            mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
            items = mdiv.findAll('article')
            for item in items:
                title = h.unescape(item.h3.text).encode('utf8')
                if '(' in title:
                    title = re.findall('(.+?)\s\(',title)[0]
                url = item.find('a')['href']
                thumb = item.find('img')['src']
                channels.append((title, thumb, url))
            Paginator = BeautifulSoup(html, parseOnlyThese=plink)
            if 'chevron-right' in str(Paginator):
                iurl = Paginator.findAll('a')[-1].get('href')
            else:
                nextpg = False
        return (sorted(channels),9) 

    def get_video(self,url):

        html = requests.get(url, headers=self.hdr, cookies=self.cj).text
        stream_url = ''

        try:
            stream_url = re.findall("Clappr\.Player.+?source:\s*'([^']+)", html)[0]
        except:
            pass
        
        if stream_url == '':
            tlink = re.findall('<iframe.+?src=[\'"]([^\'"]+)', html)[0]
            if 'file=' in tlink:
                tlink = re.findall('file=(.*)',tlink)[0]

            if 'hyfytv.' in tlink:          
                durl = 'http://hyfytv.in/i.js'

                html = requests.get(durl, headers=self.hdr,cookies=self.cj).text.replace('var ','')
                values = html.split(';')
                for value in values:
                    exec(value)

                chid = re.findall('=([^/]+)',tlink)[0]
                item_id = 1
                for item in XX11XX00XX:
                    if item['cname']==chid:
                        item_id = int(item['id'])
                        break

                cdata = XX11XX00XX[item_id-1]
                flag = cdata['flag']

                if flag == 'JY':
                    stream_url = 'http://hyfytv.in/juzplay/?/%s/%s_%s.m3u8|User-Agent=%s&Cookie=%s'%(chid,chid,self.bitrate,self.hdr['User-Agent'],self.ckstr)
                elif flag == 'Y':
                    surl = 'https://origin-api-dhtv.dailyhunt.in/v2/item/yupptvredirect/%s/master.m3u8'%cdata['cid']
                    stream_url = requests.get(surl, headers=self.hdr, allow_redirects=False).headers['Location'] + '|User-Agent=%s'%self.dhdr['User-Agent']
                else:
                    xbmc.log('%s not resolvable.\n'%tlink,xbmc.LOGNOTICE)

            elif '.m3u8' in tlink:
                stream_url = tlink + '|User-Agent=%s'%self.hdr['User-Agent']
                
            else:
                xbmc.log('%s not resolvable.\n'%tlink,xbmc.LOGNOTICE)

                       
        return stream_url