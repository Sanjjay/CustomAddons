'''
onlinemoviesgold DeccanDelight plugin
Copyright (C) 2019 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests
import HTMLParser

class omg(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.1moviesgold.com/genre/'
        self.icon = self.ipath + 'omg.png'
        self.list = {'01Tamil Movies': self.bu + 'tamil',
                     '02Telugu Movies': self.bu + 'telugu',
                     '03Malayalam Movies': self.bu + 'malayalam',
                     '04Kannada Movies': self.bu + 'kannada-movies',
                     '05Hindi Movies': self.bu + 'hindi',
                     '06English Movies': self.bu + 'hollywood',
                     '07Punjabi Movies': self.bu + 'punjabi-movies',
                     '09Bengali Movies': self.bu + 'bengali-movies',
                     '98[COLOR cyan]Adult Movies[/COLOR]': self.bu + 'adult-movies',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-6] + '?s='}
                     
    def get_menu(self):
        return (self.list,7,self.icon)
    
    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Online Movie Watch')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text
        if '?s=' in url:
            mlink = SoupStrainer('div', {'class':'result-item'})
        else:
            mlink = SoupStrainer('div', {'class':'items'})
        html = requests.get(url, headers=self.hdr).text
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        nlink = SoupStrainer('div', {'class': 'resppages'})
        npage = BeautifulSoup(html, parseOnlyThese=nlink)
        plink = SoupStrainer('div', {'class':'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('article')
        
        for item in items:
            try:
                title = h.unescape(item.h3.text)
                title = self.clean_title(title)
            except:
                tdiv = item.find('div', {'class': 'title'})
                title = h.unescape(tdiv.a.text).encode('utf8')
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
            except:
                thumb = self.icon
            movies.append((title, thumb, url))
        
        if 'icon-chevron-right' in str(npage):
            purl = Paginator.find('span', {'class': 'current'}).nextSibling.get('href')
            pgtxt = Paginator.find('span').text
            title = 'Next Page.. (Currently in {0})'.format(pgtxt)
            movies.append((title, self.nicon, purl))
        
        return (movies,8)

    def get_videos(self,url):
        videos = []
            
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'id': 'info'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        url = mdiv.find('table').nextSibling.find('a')['href']
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'entry-content'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        links = mdiv.findAll('iframe')

        for link in links:
            try:
                vidurl = link.get('src')
                self.resolve_media(vidurl,videos)
            except:
                pass
      
        return videos
