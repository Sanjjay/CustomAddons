# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from requests import get
import re,urllib,urlparse,random,json
from resources.lib.modules import cleantitle
from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['apollogroup.tv']
        self.base_link = 'http://free.apollogroup.tv'
        self.search_link = '/results?q=%s'
        self.key = '?uuid=8831ebba191eefbc'

    def movie(self, imdb, title, year):
        try:
			# print ("MUCHMOVIES RESULTS", imdb)
			movie_id = "/movie/%s" % imdb
			# print ("MUCHMOVIES RESULTS", movie_id)
			query = self.base_link + movie_id + self.key
			response = get(query)
			url = json.loads(response.text)
			url = url.replace(" ","%20")
			url = client.replaceHTMLCodes(url)
			url = url.encode('utf-8')
			return url
        except:
            return
			
			
    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        try:
            url = {'imdb': imdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return			

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
			data = urlparse.parse_qs(url)
			data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			data['season'], data['episode'] = season, episode

			imdb = data['imdb']
			# print("MUCHMOVIES EPISODES", imdb)					
			season = '%01d' % int(season)
			episode = '%01d' % int(episode)
			movie = '/tv/%s/%s/%s' % (imdb, season, episode)
			query = self.base_link + movie + self.key
			response = get(query)
			url = json.loads(response.text)
			url = url.replace(" ","%20")
			url = client.replaceHTMLCodes(url)
			url = url.encode('utf-8')
			return url

        except:
            return				
			


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url == None: return sources

            if "720" in url: quality = "HD"
            elif "1080" in url : quality = "1080p"
            else: quality = "SD"

            sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'Muchmovies', 'url': url, 'direct': True, 'debridonly': False})

            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            url = client.request(url, output='geturl')
            if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
            else: url = url.replace('https://', 'http://')
            return url
        except:
            return


