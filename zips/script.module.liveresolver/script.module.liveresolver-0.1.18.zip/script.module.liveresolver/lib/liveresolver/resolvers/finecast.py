# -*- coding: utf-8 -*-


import re,urlparse,urllib
from liveresolver.modules import client
from liveresolver.modules import jsunpack,decryptionUtils

def resolve(url):
    try:
        try:
            referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
        except:
            referer=url
        id = urlparse.parse_qs(urlparse.urlparse(url).query)['u'][0]
        url = 'http://www.finecast.tv/embed4.php?u=%s&vw=640&vh=450'%id
        result = client.request(url, referer=referer, mobile = True)
        result = decryptionUtils.doDemystify(result)
        print(result)
        file = re.findall('[\'\"](.+?.stream)[\'\"]',result)[0]
        auth = re.findall('[\'\"](\?wmsAuthSign.+?)[\'\"]',result)[0]
        rtmp = 'rtmp://play.finecast.tv:1935/live%s'%auth
        url = rtmp +  ' playpath=' + file + ' swfUrl=http://www.finecast.tv/player6/jwplayer.flash.swf flashver=WIN\2020,0,0,267 live=1 timeout=14 pageUrl=' + url

        
        return url
    except:
        return

