'''
Created on Apr 30, 2015

@author: jchirag
'''
# from xoze.snapvideo import VideoHost
from xoze.snapvideo import VideoHost, Video, STREAM_QUAL_HD_720, STREAM_QUAL_SD, UrlResolverDelegator
from xoze.utils import http, encoders
import logging
import re


VIDEO_HOST_NAME = 'letwatch'

def getVideoHost():
    video_host = VideoHost()
    video_host.set_icon('http://letwatch.us.com/images/logo.png')
    video_host.set_name(VIDEO_HOST_NAME)
    return video_host

def retrieveVideoInfo(video_id):
    videoUrl = 'http://letwatch.us/embed-' + str(video_id) + '-620x496.html'
    return UrlResolverDelegator.retrieveVideoInfo(videoUrl)
