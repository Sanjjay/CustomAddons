'''
Created on Apr 30, 2015

@author: jchirag
'''
# from xoze.snapvideo import VideoHost
from xoze.snapvideo import VideoHost, Video, STREAM_QUAL_HD_720, STREAM_QUAL_SD
from xoze.utils import http, encoders
import logging
import re

VIDEO_HOST_NAME = 'letwatch'

def getVideoHost():
    video_host = VideoHost()
    video_host.set_icon('http://letwatch.us.com/images/logo.png')
    video_host.set_name(VIDEO_HOST_NAME)
    return video_host

def retrieveVideoInfo(video_id):
    video = Video()
    video.set_video_host(getVideoHost())
    video.set_id(video_id)
    try:
        video_link = 'http://letwatch.us/embed-' + str(video_id) + '-620x496.html'
        logging.getLogger().debug('URL : ' + video_link)
        html = http.HttpClient().get_html_content(url=video_link)
        img_link = re.compile('image\: \"(.+?)\"').findall(html)[0]
        sd_video_link = re.compile('file\:\"(.+?)\",label\:\"SD\"').findall(html)
        if len(sd_video_link) > 0:
            video.add_stream_link(STREAM_QUAL_SD, sd_video_link[0])
        logging.getLogger().debug(video.get_streams())
        video.set_stopped(False)
        video.set_thumb_image(img_link)
        video.set_name("LetWatch Video")
    except:
        video.set_stopped(True)
    return video
