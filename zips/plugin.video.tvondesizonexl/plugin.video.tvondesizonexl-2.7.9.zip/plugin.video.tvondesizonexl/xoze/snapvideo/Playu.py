'''
Created on Oct 30, 2015

@author: jchirag
'''
from xoze.snapvideo import VideoHost, Video, STREAM_QUAL_SD
from xoze.utils import http
import logging
import re
import urllib2, urllib

VIDEO_HOST_NAME = 'Playu'

def getVideoHost():
    video_host = VideoHost()
    video_host.set_icon('http://playu.net/img/logo2-new-res-sm2.png')
    video_host.set_name(VIDEO_HOST_NAME)
    return video_host

def retrieveVideoInfo(video_id):    
    video = Video()
    video.set_video_host(getVideoHost())
    video.set_id(video_id)
    try:
        video_link = 'http://playu.net/embed-' + str(video_id) + '.html'
        req = urllib2.Request(video_link)
        req.add_header('User-Agent', 'Mozilla/5.0 (iPad; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3')
        response = urllib2.urlopen(req)
        html=response.read()

        final_url = re.compile('file\:\s*\"(.+?(.mp4|.m3u8))\"').findall(html)[0][0]
        image_url = re.compile('image\:\s*\"(.+?)\"').findall(html)[0]

        video.set_stopped(False)
        video.set_thumb_image(image_url)
        video.set_name("Playu Video")
        video.add_stream_link(STREAM_QUAL_SD, final_url)
        logging.getLogger().debug(video.get_streams())
    except:
        video.set_stopped(True)
    return video
