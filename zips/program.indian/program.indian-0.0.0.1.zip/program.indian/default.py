
import xbmcgui

xbmcgui.Dialog().ok('Addon Broken', 'Select Ok and right click on this addon', 'Select "Addon Information"', 'then Uninstall Addon.')